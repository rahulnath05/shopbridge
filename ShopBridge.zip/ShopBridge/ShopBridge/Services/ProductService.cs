﻿using Microsoft.EntityFrameworkCore;
using ShopBridge.Model;
using ShopBridge.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge.Services
{
    public class ProductService
    {
        private readonly ProductDBContext productDBContext;

        public ProductService(ProductDBContext dBContext)
        {
            productDBContext = dBContext;
        }

        public async Task<List<Product>> GetAllProductsAsync()
        {
            try
            {
                using (productDBContext)
                {
                    var products = await productDBContext.Products.AsQueryable<Product>().ToListAsync();
                    return products.OrderBy(x => x.Id).ToList();
                }

            }
            catch (Exception Ex)
            {
                throw new Exception(Ex.Message);
            }
        }

        public async Task<List<Product>> AddProductAsync(Product product)
        {
            using (productDBContext)
            {
                try
                {
                    await productDBContext.Products.AddAsync(product);
                    await productDBContext.SaveChangesAsync();

                    return await GetAllProductsAsync();
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }
        }

        public async Task<Product> UpdateProductsAsync(Product product, int productId)
        {
            using (productDBContext)
            {
                try
                {
                    var item = await productDBContext.Products.FirstOrDefaultAsync(x => x.Id == productId);

                    if (item == null)
                    {
                        throw new Exception("Invalid Product Id");
                    }

                    item.Name = product.Name;
                    item.Description = product.Description;
                    item.ManufacturedBy = product.ManufacturedBy;
                    item.Price = product.Price;

                    productDBContext.Products.Update(item);
                    await productDBContext.SaveChangesAsync();

                    return item;
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }

        }

        public async Task<bool> DeleteProductAsync(int productId)
        {
            using (productDBContext)
            {
                try
                {
                    var item = await productDBContext.Products.FirstOrDefaultAsync(x => x.Id == productId);
                    if (item != null)
                    {

                        productDBContext.Remove(item);
                        await productDBContext.SaveChangesAsync();
                        return true;
                    }
                    else
                    {
                        throw new Exception("Item not found");
                    }
                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }
            }
        }
    }
}
